# SPTI 组合式独立控制面板

## 内容
- `STPI_Activation.sh`：唯一启动脚本，执行 Android/内核检查、Supabase 卡密验证、配置档选择并启动 APK。
- `STPI_Control_App/`：Android Studio 配套工程，提供小悬浮球、展开面板、开场动画和交互按钮。

## 安装
1. 用 Android Studio 打开 `STPI_Control_App` 并构建 debug APK。
2. 安装 APK，首次打开后授予“显示在其他应用上层”权限。
3. 将 `STPI_Activation.sh` 放到手机 `/sdcard/STPI/`。
4. 在 MT 管理器中运行该 `.sh` 文件。
5. 授权成功后 APK 启动页出现；点击“启动 SPTI 悬浮控制窗”，屏幕边缘出现小悬浮球；点击悬浮球展开面板。

## 功能边界
绘制人物/方框/骨骼、智能绘制、子追、自瞄和范围开关是本地界面演示控件，仅改变界面状态，不读取或修改游戏画面、内存或网络数据，不执行游戏辅助或反作弊规避。界面标注 DEMO PANEL。
本源码尚未编译成 APK，也未在目标手机实机验证。Android Studio/Gradle 构建后才可安装。
