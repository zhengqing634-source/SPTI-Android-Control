#!/system/bin/sh
# SPTI launcher. Run this file from MT Manager.
STPI_DIR="/sdcard/STPI"
CONFIG_DIR="$STPI_DIR/config"
LOG_DIR="$STPI_DIR/logs"
LOG_FILE="$LOG_DIR/activation.log"
API_URL="https://moortluitlpcuhqzfqky.supabase.co/functions/v1/stpi-license-activation"
PUBLIC_KEY="sb_publishable_DyV6nf8RVv-d-XllYdt0LQ_uJG87R_L"
APP_PACKAGE="com.stpi.control"
APP_COMPONENT="com.stpi.control/.MainActivity"

mkdir -p "$CONFIG_DIR" "$LOG_DIR" || exit 1
log(){ printf '%s %s\n' "$(date '+%F %T' 2>/dev/null)" "$1" >> "$LOG_FILE"; }
say(){ printf '\n[SPTI] %s\n' "$1"; }

SDK="$(getprop ro.build.version.sdk 2>/dev/null)"
KERNEL="$(uname -r 2>/dev/null)"
case "$SDK" in ''|*[!0-9]*) say "无法读取 Android SDK 版本"; exit 1;; esac
[ "$SDK" -ge 34 ] || { say "需要 Android 14 或更高版本"; exit 1; }
case "$KERNEL" in 6.[1-9]*|6.[1-9][0-9]*|[7-9].*) ;; *) say "无法确认内核版本达到 6.1"; exit 1;; esac
command -v curl >/dev/null 2>&1 || { say "缺少 curl，无法验证授权"; exit 1; }

DEVICE_FILE="$CONFIG_DIR/device.id"
if [ ! -s "$DEVICE_FILE" ]; then
  od -An -N16 -tx1 /dev/urandom 2>/dev/null | tr -d ' \n' > "$DEVICE_FILE"
fi
DEVICE_ID="$(tr -d '\r\n' < "$DEVICE_FILE" 2>/dev/null)"
case "$DEVICE_ID" in *[!0123456789abcdefABCDEF]*|'') say "设备标识文件异常"; exit 1;; esac
[ "${#DEVICE_ID}" -eq 32 ] || { say "设备标识长度异常"; exit 1; }

say "请输入卡密（输入内容不会显示）"
stty -echo 2>/dev/null
IFS= read -r LICENSE_KEY
stty echo 2>/dev/null
printf '\n'
[ -n "$LICENSE_KEY" ] || { say "卡密不能为空"; exit 1; }
escape_json(){ printf '%s' "$1" | sed 's/\\/\\\\/g; s/"/\\"/g'; }
K="$(escape_json "$LICENSE_KEY")"
D="$(escape_json "$DEVICE_ID")"
RESPONSE="$(curl -sS --connect-timeout 10 --max-time 25 -X POST "$API_URL" \
  -H "Content-Type: application/json" -H "apikey: $PUBLIC_KEY" \
  -H "Authorization: Bearer $PUBLIC_KEY" \
  --data "{\"action\":\"activate\",\"key\":\"$K\",\"device_id\":\"$D\"}" 2>/dev/null)"
unset LICENSE_KEY K D DEVICE_ID
if printf '%s' "$RESPONSE" | grep -q '"ok"[[:space:]]*:[[:space:]]*true'; then
  say "卡密验证成功"; log "License activation accepted"
else
  say "卡密验证失败或网络不可用"; log "License activation rejected or network error"
  unset RESPONSE; exit 1
fi
unset RESPONSE

say "配置档：1=twt  2=GTv  3=AxAeRifvX（默认）"
printf "请选择，5 秒无操作默认 3："
ANSWER=""
if read -r -t 5 ANSWER 2>/dev/null; then :; else ANSWER="3"; fi
case "$ANSWER" in 1) PROFILE="twt";; 2) PROFILE="GTv";; *) PROFILE="AxAeRifvX";; esac
printf '%s\n' "$PROFILE" > "$CONFIG_DIR/profile"
log "Profile selected: $PROFILE"

if ! pm path "$APP_PACKAGE" >/dev/null 2>&1; then
  say "未安装 SPTI 配套 APK，请先编译并安装工程中的 APK"; exit 1
fi
say "正在打开 SPTI 控制面板"
am start -n "$APP_COMPONENT" --es profile "$PROFILE" >/dev/null 2>&1
log "SPTI launcher activity requested"
say "首次请在 APK 中授予悬浮窗权限，再点击启动悬浮控制窗"
