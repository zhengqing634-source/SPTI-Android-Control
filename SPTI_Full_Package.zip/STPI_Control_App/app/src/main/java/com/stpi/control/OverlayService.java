package com.stpi.control;
import android.app.Service;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.Typeface;
import android.os.IBinder;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.view.animation.AlphaAnimation;
import android.animation.ValueAnimator;
import android.widget.Toast;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.SeekBar;

public class OverlayService extends Service {
  WindowManager wm; View bubble,panel; WindowManager.LayoutParams bp,pp; String profile="AxAeRifvX";
  int dp(float n){return (int)(n*getResources().getDisplayMetrics().density);}
  TextView txt(String s,int size,int color){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);t.setPadding(dp(8),dp(7),dp(8),dp(7));return t;}
  Button button(String s,Runnable r){Button b=new Button(this);b.setText(s);b.setOnClickListener(v->r.run());return b;}
  void fade(View v){AlphaAnimation a=new AlphaAnimation(0f,1f);a.setDuration(420);v.startAnimation(a);}
  void drag(View v,WindowManager.LayoutParams p){v.setOnTouchListener(new View.OnTouchListener(){float x,y;int ox,oy;public boolean onTouch(View w,MotionEvent e){if(e.getAction()==0){x=e.getRawX();y=e.getRawY();ox=p.x;oy=p.y;return false;}if(e.getAction()==2){p.x=ox-(int)(e.getRawX()-x);p.y=oy+(int)(e.getRawY()-y);try{wm.updateViewLayout(v,p);}catch(Exception ignored){}return true;}return false;}});}
  void status(String s){Toast.makeText(this,s,Toast.LENGTH_SHORT).show();if(panel!=null)panel.announceForAccessibility(s);}
  void showBubble(){
    TextView b=txt("ＳＰＴＩ  ☰",18,Color.rgb(135,200,255));b.setGravity(Gravity.CENTER);b.setTypeface(Typeface.DEFAULT_BOLD);b.setBackgroundColor(Color.rgb(18,31,51));bubble=b;
    bp=new WindowManager.LayoutParams(dp(118),dp(54),WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,PixelFormat.TRANSLUCENT);
    bp.gravity=Gravity.TOP|Gravity.END;bp.x=dp(12);bp.y=dp(150);wm.addView(bubble,bp);fade(bubble);drag(bubble,bp);bubble.setOnClickListener(v->expand());
  }
  void addToggle(LinearLayout box,String name){
    final boolean[] on={false}; Button b=button(name+"：关闭",()->{on[0]=!on[0];b.setText(name+"："+(on[0]?"开启":"关闭"));fade(b);});
    box.addView(b);
  }
  void expand(){
    if(panel!=null)return;
    ScrollView scroll=new ScrollView(this);LinearLayout box=new LinearLayout(this);box.setOrientation(1);box.setPadding(dp(10),dp(8),dp(10),dp(8));box.setBackgroundColor(Color.rgb(15,24,40));
    ValueAnimator bg=ValueAnimator.ofArgb(Color.rgb(15,24,40),Color.rgb(22,36,58),Color.rgb(15,24,40));
    bg.setDuration(5200);bg.setRepeatCount(ValueAnimator.INFINITE);bg.setRepeatMode(ValueAnimator.RESTART);
    bg.addUpdateListener(a->box.setBackgroundColor((Integer)a.getAnimatedValue()));bg.start();
    TextView brand=txt("ＳＰＴＩ",28,Color.rgb(130,198,255));brand.setGravity(Gravity.CENTER);brand.setTypeface(Typeface.DEFAULT_BOLD);box.addView(brand);
    box.addView(txt("SYSTEM CONTROL INTERFACE  •  DEMO PANEL",9,Color.LTGRAY));box.addView(txt("配置档："+profile,12,Color.WHITE));
    box.addView(txt("配置",17,Color.rgb(130,198,255)));
    box.addView(button("读取数据",()->status("已读取本地演示配置")));
    box.addView(button("保存配置",()->status("演示配置已保存")));
    box.addView(button("退出辅助",()->stopSelf()));
    box.addView(txt("绘制",17,Color.rgb(130,198,255)));
    addToggle(box,"智能绘制");addToggle(box,"绘制人物");addToggle(box,"绘制方框");addToggle(box,"绘制骨骼");
    box.addView(txt("功能",17,Color.rgb(130,198,255)));
    addToggle(box,"子追（力度调节）");addToggle(box,"自瞄");addToggle(box,"范围");
    box.addView(txt("子追力度",12,Color.WHITE));SeekBar strength=new SeekBar(this);strength.setMax(100);strength.setProgress(50);box.addView(strength);
    box.addView(button("启动游戏",()->{try{Intent g=getPackageManager().getLaunchIntentForPackage("com.miniworldroyale.sparkgame.mi");if(g==null)status("未找到游戏");else{g.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);startActivity(g);status("已发送游戏启动请求");}}catch(Exception e){status("启动请求失败");}}));
    box.addView(button("收起面板",()->collapse()));box.addView(button("关闭 SPTI",()->stopSelf()));
    scroll.addView(box);panel=scroll;
    pp=new WindowManager.LayoutParams(dp(300),dp(560),WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE|WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,PixelFormat.TRANSLUCENT);
    pp.gravity=Gravity.TOP|Gravity.END;pp.x=dp(8);pp.y=dp(105);wm.addView(panel,pp);fade(panel);drag(panel,pp);
  }
  void collapse(){if(panel!=null){wm.removeView(panel);panel=null;}if(bubble==null)showBubble();}
  @Override public int onStartCommand(Intent i,int f,int id){if(i!=null&&i.getStringExtra("profile")!=null)profile=i.getStringExtra("profile");wm=(WindowManager)getSystemService(WINDOW_SERVICE);if(bubble==null&&panel==null)showBubble();return START_NOT_STICKY;}
  @Override public void onDestroy(){if(panel!=null){wm.removeView(panel);panel=null;}if(bubble!=null){wm.removeView(bubble);bubble=null;}super.onDestroy();}
  @Override public IBinder onBind(Intent i){return null;}
}
