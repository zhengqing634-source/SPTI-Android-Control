package com.stpi.control;
import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.graphics.Color;
import android.view.Gravity;
import android.view.animation.AlphaAnimation;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MainActivity extends Activity {
  int dp(float n){return (int)(n*getResources().getDisplayMetrics().density);}
  @Override public void onCreate(Bundle b){
    super.onCreate(b);
    getWindow().setStatusBarColor(Color.rgb(10,16,29));
    getWindow().setNavigationBarColor(Color.rgb(10,16,29));
    LinearLayout root=new LinearLayout(this); root.setOrientation(1); root.setGravity(Gravity.CENTER);
    root.setPadding(dp(24),dp(24),dp(24),dp(24)); root.setBackgroundColor(Color.rgb(10,16,29));
    TextView logo=new TextView(this); logo.setText("ＳＰＴＩ"); logo.setTextSize(42); logo.setTextColor(Color.rgb(125,190,255)); logo.setGravity(Gravity.CENTER);
    TextView sub=new TextView(this); sub.setText("SYSTEM CONTROL INTERFACE\\n组合式独立控制面板"); sub.setTextColor(Color.WHITE); sub.setGravity(Gravity.CENTER);
    Button perm=new Button(this); perm.setText("授予屏幕悬浮窗权限");
    Button open=new Button(this); open.setText("启动 SPTI 悬浮控制窗");
    root.addView(logo); root.addView(sub); root.addView(perm); root.addView(open); setContentView(root);
    AlphaAnimation intro=new AlphaAnimation(0f,1f); intro.setDuration(1000); root.startAnimation(intro);
    perm.setOnClickListener(v->{if(!Settings.canDrawOverlays(this)) startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,Uri.parse("package:"+getPackageName()))); else perm.setText("悬浮窗权限已授予");});
    open.setOnClickListener(v->{
      if(!Settings.canDrawOverlays(this)){perm.performClick();return;}
      Intent i=new Intent(this,OverlayService.class); String p=getIntent().getStringExtra("profile"); i.putExtra("profile",p==null?"AxAeRifvX":p); startService(i); open.setText("悬浮窗已启动");
    });
  }
}
