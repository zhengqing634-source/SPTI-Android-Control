# SPTI Formal 2.1.0

## 本版内容
- 正式启动流程：`STPI_Activation.sh` -> 设备授权状态检查/激活 -> 服务端签发 5 分钟 HMAC 启动票据 -> APK 服务端验证 -> 显示控制台。
- APK 直接从桌面图标启动时，因为没有启动票据会拒绝进入。
- Activity 与 OverlayService 分别验证票据；OverlayService 不接受无票据的独立启动，避免通过辅助服务绕过启动门禁。
- 音量 +：展开悬浮控制面板；音量 -：隐藏控制面板并保留悬浮球。
- 音量键控制需在 Android 无障碍设置中手动启用“SPTI 音量键控制”。启用后音量键事件会被接管，不再用于媒体音量调节。
- 面板按钮仍仅为本地 UI 演示，不读取或修改游戏数据。

## 授权与数据边界
- 保留现有 `stpi-license-activation` 激活/状态函数，不修改数据库表、不修改卡密、不解绑设备。
- 使用现有 `stpi-launch-ticket` 的 `issue` / `verify` 接口。
- HMAC 签名密钥只保留在 Supabase Edge Function Secrets，不写入 APK 或 shell 脚本。
- APK 和脚本只包含 Supabase publishable API key（公开客户端 key）。
- 设备 ID 沿用 `/sdcard/STPI/config/device.id`，以便兼容之前已经绑定的设备。

## Android 启动
1. 安装 APK。
2. 在 MT 管理器或支持 `sh` 与 `curl` 的 Android 终端中运行 `STPI_Activation.sh`。
3. 首次运行若设备未激活，按提示输入授权卡密；脚本不会将卡密写入文件。
4. 授权通过后脚本申请短时票据并启动 APK。
5. 在 Android 设置 -> 无障碍中启用 SPTI 音量键控制。
6. 授予“显示在其他应用上层”权限，然后在 SPTI 主界面启动悬浮控制台。

## 构建
- JDK 17
- Gradle 8.9
- Android Gradle Plugin 8.7.3
- compileSdk 35 / minSdk 26
- 执行：`gradle -p STPI_Control_App :app:assembleDebug`
- 输出：`STPI_Control_App/app/build/outputs/apk/debug/app-debug.apk`

此源包尚未在 Android SDK/Gradle 构建环境中编译，也未在实体设备上做端到端测试。正式发布前必须通过 GitHub Actions 构建，并在设备上验证：无票据拒绝启动、有效票据启动、过期票据拒绝、音量键展开/隐藏、无障碍权限关闭时的行为。


## Root 权限要求（正式版）

正式版启动必须同时满足：
1. 在终端运行 `STPI_Activation.sh` 时，脚本通过 `su -c id` 检查并取得 `uid=0`。
2. APK 启动后再次调用 `su -c id`，确认 Root 管理器已授予该应用 Root 权限。
3. Root 检查通过后，APK 才继续验证服务端短时启动票据。

拒绝 Root 授权、超时或未检测到 `uid=0` 时，应用拒绝进入控制界面。脚本与 APK 不包含 Root 管理器的授权密钥，也不执行游戏进程注入、内存修改或其他游戏操作。
