package com.stpi.control;

import android.app.Service;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.IBinder;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.*;
import org.json.JSONObject;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import android.animation.ValueAnimator;

public class OverlayService extends Service {
    public static final String ACTION_EXPAND = "com.stpi.control.ACTION_EXPAND";
    public static final String ACTION_HIDE_PANEL = "com.stpi.control.ACTION_HIDE_PANEL";
    private static final String TICKET_URL = "https://moortluitlpcuhqzfqky.supabase.co/functions/v1/stpi-launch-ticket";
    private final ExecutorService authExecutor = Executors.newSingleThreadExecutor();
    private boolean authorizedSession = false;
    private boolean authorizationPending = false;
    private WindowManager wm;
    private View bubble, panel;
    private WindowManager.LayoutParams bubbleParams, panelParams;
    private final int CYAN=Color.rgb(79,214,255), MUTED=Color.rgb(155,179,204);
    @Override public void onCreate() {
        super.onCreate();
        wm=(WindowManager)getSystemService(WINDOW_SERVICE);
    }
    private int dp(float x){return (int)(x*getResources().getDisplayMetrics().density+.5f);}
    private GradientDrawable bg(int c,int stroke,int r){
        GradientDrawable d=new GradientDrawable(GradientDrawable.Orientation.TL_BR,new int[]{c,Color.rgb(9,24,45)});
        d.setCornerRadius(dp(r)); if(stroke!=0)d.setStroke(dp(1),stroke); return d;
    }
    private TextView txt(String s,int size,int color,boolean bold){
        TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);
        if(bold)t.setTypeface(Typeface.create("sans-serif",Typeface.BOLD));
        return t;
    }
    private LinearLayout col(){LinearLayout l=new LinearLayout(this);l.setOrientation(1);return l;}
    private LinearLayout.LayoutParams p(int w,int h){return new LinearLayout.LayoutParams(w<0?w:dp(w),h<0?h:dp(h));}
    private WindowManager.LayoutParams params(int w,int h,int gravity){
        int type=Build.VERSION.SDK_INT>=26?WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY:WindowManager.LayoutParams.TYPE_PHONE;
        WindowManager.LayoutParams lp = new WindowManager.LayoutParams(w<0?w:dp(w),h<0?h:dp(h),type,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE|WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT);
        lp.gravity = gravity;
        return lp;
    }
    private void showBubble(){
        if(bubble!=null)return;
        TextView b=txt("S",20,Color.WHITE,true);b.setGravity(Gravity.CENTER);
        b.setBackground(bg(Color.rgb(13,78,115),CYAN,28));b.setElevation(dp(10));
        bubble=b; bubbleParams=params(56,56,Gravity.TOP|Gravity.START);
        bubbleParams.x=dp(18);bubbleParams.y=dp(180);
        b.setOnClickListener(v->togglePanel());
        b.setOnTouchListener(new View.OnTouchListener(){
            float sx,sy;int ox,oy;long down;
            public boolean onTouch(View v,MotionEvent e){
                if(e.getAction()==0){sx=e.getRawX();sy=e.getRawY();ox=bubbleParams.x;oy=bubbleParams.y;down=System.currentTimeMillis();return false;}
                if(e.getAction()==2){bubbleParams.x=ox+(int)(e.getRawX()-sx);bubbleParams.y=oy+(int)(e.getRawY()-sy);wm.updateViewLayout(bubble,bubbleParams);return true;}
                return false;
            }});
        wm.addView(bubble,bubbleParams);
        ValueAnimator a=ValueAnimator.ofFloat(.82f,1f);a.setDuration(1200);a.setRepeatCount(ValueAnimator.INFINITE);a.setRepeatMode(ValueAnimator.REVERSE);
        a.addUpdateListener(v->{if(bubble!=null)bubble.setAlpha((Float)v.getAnimatedValue());});a.start();
    }
    private void togglePanel(){if(panel==null)showPanel();else hidePanel();}
    private void showPanel(){
        LinearLayout root=col();root.setPadding(dp(16),dp(15),dp(16),dp(15));
        root.setBackground(bg(Color.rgb(10,25,47),Color.rgb(54,151,193),24));root.setElevation(dp(18));
        LinearLayout head=new LinearLayout(this);head.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout brand=col();brand.addView(txt("SPTI  /  CONTROL",13,Color.WHITE,true));brand.addView(txt("FLOATING COMMAND PANEL",9,MUTED,false));
        head.addView(brand,new LinearLayout.LayoutParams(0,-2,1));
        TextView close=txt("×",25,Color.WHITE,true);close.setGravity(Gravity.CENTER);close.setBackground(bg(Color.rgb(25,53,78),0,20));head.addView(close,p(38,38));
        close.setOnClickListener(v->hidePanel());root.addView(head);
        TextView status=txt("●  LOCAL DEMO INTERFACE     •     READY",9,CYAN,true);
        status.setPadding(0,dp(12),0,dp(10));root.addView(status);
        ScrollView scroll=new ScrollView(this);LinearLayout body=col();scroll.addView(body);
        section(body,"01  配置中心","读取数据","保存配置","退出辅助");
        section(body,"02  绘制中心","智能绘制","绘制人物","绘制方框","绘制骨骼");
        section(body,"03  功能中心","子追演示","自瞄演示","范围演示");
        TextView strength=txt("子追力度演示调节",11,MUTED,true);LinearLayout.LayoutParams st=p(-1,30);st.topMargin=dp(8);body.addView(strength,st);
        SeekBar seek=new SeekBar(this);seek.setMax(100);seek.setProgress(50);body.addView(seek,p(-1,36));
        TextView note=txt("说明：以上开关仅演示面板状态，不连接或修改游戏数据。",9,MUTED,false);
        note.setPadding(0,dp(9),0,0);body.addView(note);
        root.addView(scroll,new LinearLayout.LayoutParams(-1,dp(410)));
        TextView game=txt("打开游戏",13,Color.rgb(5,24,37),true);game.setGravity(Gravity.CENTER);
        game.setBackground(bg(Color.rgb(68,199,238),Color.rgb(132,233,255),14));
        LinearLayout.LayoutParams gp=p(-1,46);gp.topMargin=dp(10);root.addView(game,gp);
        game.setOnClickListener(v->Toast.makeText(this,"此演示面板不自动连接游戏",Toast.LENGTH_SHORT).show());
        panel=root;panelParams=params(320,-2,Gravity.TOP|Gravity.END);panelParams.x=dp(12);panelParams.y=dp(90);
        wm.addView(panel,panelParams);
        panel.setAlpha(0f);panel.setScaleX(.96f);panel.setScaleY(.96f);
        panel.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(220).start();
    }
    private void section(LinearLayout parent,String title,String... labels){
        LinearLayout card=col();card.setPadding(dp(12),dp(10),dp(12),dp(10));
        card.setBackground(bg(Color.rgb(15,36,61),Color.rgb(34,73,104),16));
        LinearLayout.LayoutParams cp=p(-1,-2);cp.topMargin=dp(7);parent.addView(card,cp);
        card.addView(txt(title,12,Color.WHITE,true));
        for(String label:labels){
            TextView b=txt(label+"     ›",11,MUTED,true);b.setGravity(Gravity.CENTER_VERTICAL);
            b.setPadding(dp(10),0,dp(8),0);b.setBackground(bg(Color.rgb(9,25,44),Color.rgb(31,64,91),10));
            LinearLayout.LayoutParams bp=p(-1,36);bp.topMargin=dp(7);card.addView(b,bp);
            b.setOnClickListener(v->{
                boolean on=Boolean.TRUE.equals(v.getTag());v.setTag(!on);
                b.setText(label+(on?"     ›":"     ✓ 已选中"));
                b.setTextColor(on?MUTED:CYAN);
                b.setBackground(bg(on?Color.rgb(9,25,44):Color.rgb(12,57,75),on?Color.rgb(31,64,91):Color.rgb(45,155,184),10));
                Toast.makeText(this,label+(on?" 已关闭":" 已开启演示状态"),Toast.LENGTH_SHORT).show();
            });
        }
    }
    private void hidePanel(){if(panel!=null){try{wm.removeView(panel);}catch(Exception ignored){}panel=null;}}
    @Override public int onStartCommand(Intent i,int flags,int id){
        if (!authorizedSession) {
            if (authorizationPending) return START_NOT_STICKY;
            String ticket = i == null ? null : i.getStringExtra("launch_ticket");
            String deviceId = i == null ? null : i.getStringExtra("device_id");
            if (ticket == null || ticket.isEmpty() || deviceId == null || deviceId.length() < 16) {
                stopSelf();
                return START_NOT_STICKY;
            }
            authorizationPending = true;
            verifyTicketForService(ticket, deviceId);
            return START_NOT_STICKY;
        }
        applyCommand(i);
        return START_NOT_STICKY;
    }

    private void applyCommand(Intent i) {
        if (bubble == null) showBubble();
        if (i != null && ACTION_EXPAND.equals(i.getAction())) {
            if (panel == null) showPanel();
        } else if (i != null && ACTION_HIDE_PANEL.equals(i.getAction())) {
            hidePanel();
        }
    }

    private void verifyTicketForService(String ticket, String deviceId) {
        authExecutor.execute(() -> {
            boolean valid = false;
            HttpURLConnection connection = null;
            try {
                JSONObject body = new JSONObject();
                body.put("action", "verify");
                body.put("ticket", ticket);
                body.put("device_id", deviceId);
                connection = (HttpURLConnection) new URL(TICKET_URL).openConnection();
                connection.setRequestMethod("POST");
                connection.setConnectTimeout(10000);
                connection.setReadTimeout(10000);
                connection.setDoOutput(true);
                connection.setRequestProperty("Content-Type", "application/json; charset=utf-8");
                connection.setRequestProperty("apikey", "sb_publishable_DyV6nf8RVv-d-XllYdt0LQ_uJG87R_L");
                try (OutputStream out = connection.getOutputStream()) {
                    out.write(body.toString().getBytes(StandardCharsets.UTF_8));
                }
                int code = connection.getResponseCode();
                java.io.InputStream stream = code >= 200 && code < 300 ? connection.getInputStream() : connection.getErrorStream();
                java.io.ByteArrayOutputStream buffer = new java.io.ByteArrayOutputStream();
                if (stream != null) {
                    byte[] chunk = new byte[1024]; int n;
                    while ((n = stream.read(chunk)) > 0) buffer.write(chunk, 0, n);
                    stream.close();
                }
                JSONObject response = new JSONObject(buffer.toString("UTF-8"));
                valid = code == 200 && response.optBoolean("ok") && response.optBoolean("valid");
            } catch (Exception ignored) {
                valid = false;
            } finally { if (connection != null) connection.disconnect(); }
            final boolean accepted = valid;
            new android.os.Handler(android.os.Looper.getMainLooper()).post(() -> {
                authorizationPending = false;
                if (accepted) {
                    authorizedSession = true;
                    applyCommand(null);
                } else {
                    stopSelf();
                }
            });
        });
    }

    @Override public void onDestroy(){
        authExecutor.shutdownNow();
        hidePanel();if(bubble!=null){try{wm.removeView(bubble);}catch(Exception ignored){}bubble=null;}
        super.onDestroy();
    }
    @Override public IBinder onBind(Intent i){return null;}
}
