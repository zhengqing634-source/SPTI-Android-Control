package com.stpi.control;

import android.accessibilityservice.AccessibilityService;
import android.view.KeyEvent;
import android.content.Intent;
import android.view.accessibility.AccessibilityEvent;

public class VolumeKeyAccessibilityService extends AccessibilityService {
    @Override public void onAccessibilityEvent(AccessibilityEvent event) { }
    @Override public void onInterrupt() { }

    @Override protected boolean onKeyEvent(KeyEvent event) {
        if (event == null) return super.onKeyEvent(event);
        int code = event.getKeyCode();
        if (code != KeyEvent.KEYCODE_VOLUME_UP && code != KeyEvent.KEYCODE_VOLUME_DOWN) {
            return super.onKeyEvent(event);
        }
        if (event.getAction() == KeyEvent.ACTION_DOWN && event.getRepeatCount() == 0) {
            Intent command = new Intent(this, OverlayService.class);
            command.setAction(code == KeyEvent.KEYCODE_VOLUME_UP
                    ? OverlayService.ACTION_EXPAND : OverlayService.ACTION_HIDE_PANEL);
            try { startService(command); } catch (Exception ignored) { }
        }
        return true;
    }
}
