package com.stpi.control;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.provider.Settings.Secure;
import org.json.JSONObject;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.concurrent.TimeUnit;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.view.animation.DecelerateInterpolator;
import android.animation.ValueAnimator;
import android.widget.*;

public class MainActivity extends Activity {
    private static final String TICKET_URL = "https://moortluitlpcuhqzfqky.supabase.co/functions/v1/stpi-launch-ticket";
    private final ExecutorService authExecutor = Executors.newSingleThreadExecutor();
    private boolean authorized = false;
    private String verifiedTicket;
    private String verifiedDeviceId;
    private TextView authStatus;

    private final int BG = Color.rgb(5, 12, 27);
    private final int PANEL = Color.rgb(13, 27, 49);
    private final int CYAN = Color.rgb(72, 211, 255);
    private final int MUTED = Color.rgb(142, 166, 194);

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);
        getWindow().getDecorView().setSystemUiVisibility(0);
        showAuthScreen();
        Intent launch = getIntent();
        beginAuthorizedLaunch(launch == null ? null : launch.getStringExtra("launch_ticket"),
                launch == null ? null : launch.getStringExtra("device_id"));
    }

    @Override protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        authorized = false;
        verifiedTicket = null;
        verifiedDeviceId = null;
        showAuthScreen();
        beginAuthorizedLaunch(intent.getStringExtra("launch_ticket"), intent.getStringExtra("device_id"));
    }

    private void beginAuthorizedLaunch(String ticket, String deviceId) {
        authExecutor.execute(() -> {
            boolean rootGranted = hasRootAccess();
            runOnUiThread(() -> {
                if (isFinishing()) return;
                if (!rootGranted) {
                    rejectLaunch("必须授予 Root（UID 0）权限才能使用 SPTI。请在 Root 管理器中允许后重新通过 .sh 启动。");
                    return;
                }
                verifyLaunchTicket(ticket, deviceId);
            });
        });
    }

    private boolean hasRootAccess() {
        Process process = null;
        try {
            process = new ProcessBuilder("su", "-c", "id").redirectErrorStream(true).start();
            if (!process.waitFor(30, TimeUnit.SECONDS)) {
                process.destroyForcibly();
                return false;
            }
            StringBuilder output = new StringBuilder();
            try (BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream(), StandardCharsets.UTF_8))) {
                String line;
                while ((line = reader.readLine()) != null) output.append(line).append('\n');
            }
            return process.exitValue() == 0 && output.toString().contains("uid=0");
        } catch (Exception e) {
            if (process != null) process.destroyForcibly();
            return false;
        }
    }

    private void showAuthScreen() {
        LinearLayout root = column();
        root.setGravity(Gravity.CENTER);
        root.setPadding(dp(28), dp(28), dp(28), dp(28));
        root.setBackground(new GradientDrawable(GradientDrawable.Orientation.TL_BR,
                new int[]{Color.rgb(7,17,37), Color.rgb(4,10,23), Color.rgb(8,25,48)}));
        TextView logo = text("SPTI", 30, Color.WHITE, true);
        logo.setGravity(Gravity.CENTER);
        root.addView(logo, lp(-1, 60));
        authStatus = text("正在验证启动授权…", 14, CYAN, true);
        authStatus.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams sp = lp(-1, 54); sp.topMargin = dp(12); root.addView(authStatus, sp);
        TextView hint = text("请通过 STPI_Activation.sh 启动应用", 11, MUTED, false);
        hint.setGravity(Gravity.CENTER); root.addView(hint, lp(-1, 32));
        setContentView(root);
    }

    private void verifyLaunchTicket(String ticket, String deviceId) {
        if (ticket == null || ticket.isEmpty() || deviceId == null || deviceId.length() < 16) {
            rejectLaunch("未检测到有效启动票据。请使用 .sh 文件启动。");
            return;
        }
        authExecutor.execute(() -> {
            boolean valid = false;
            String message = "授权验证失败，请重新通过 .sh 启动";
            HttpURLConnection connection = null;
            try {
                JSONObject body = new JSONObject();
                body.put("action", "verify");
                body.put("ticket", ticket);
                body.put("device_id", deviceId);
                connection = (HttpURLConnection) new URL(TICKET_URL).openConnection();
                connection.setRequestMethod("POST");
                connection.setConnectTimeout(10000);
                connection.setReadTimeout(10000);
                connection.setDoOutput(true);
                connection.setRequestProperty("Content-Type", "application/json; charset=utf-8");
                connection.setRequestProperty("apikey", "sb_publishable_DyV6nf8RVv-d-XllYdt0LQ_uJG87R_L");
                byte[] payload = body.toString().getBytes(StandardCharsets.UTF_8);
                try (OutputStream out = connection.getOutputStream()) { out.write(payload); }
                int code = connection.getResponseCode();
                java.io.InputStream stream = code >= 200 && code < 300 ? connection.getInputStream() : connection.getErrorStream();
                java.io.ByteArrayOutputStream buffer = new java.io.ByteArrayOutputStream();
                if (stream != null) { byte[] chunk = new byte[1024]; int n; while ((n = stream.read(chunk)) > 0) buffer.write(chunk, 0, n); stream.close(); }
                JSONObject response = new JSONObject(buffer.toString("UTF-8"));
                valid = code == 200 && response.optBoolean("ok") && response.optBoolean("valid");
                if (!valid) message = response.optString("error", message);
            } catch (Exception ignored) {
                message = "网络验证失败，请检查网络后重新运行 .sh";
            } finally { if (connection != null) connection.disconnect(); }
            final boolean accepted = valid;
            final String resultMessage = message;
            runOnUiThread(() -> {
                if (isFinishing()) return;
                if (accepted) {
                    authorized = true;
                    verifiedTicket = ticket;
                    verifiedDeviceId = deviceId;
                    buildScreen();
                } else rejectLaunch(resultMessage);
            });
        });
    }

    private void rejectLaunch(String message) {
        if (authStatus != null) authStatus.setText(message);
        Toast.makeText(this, message, Toast.LENGTH_LONG).show();
        authStatus.postDelayed(this::finish, 1800);
    }

    private GradientDrawable shape(int color, int stroke, int radius) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color); d.setCornerRadius(dp(radius));
        if (stroke != 0) d.setStroke(dp(1), stroke);
        return d;
    }
    private int dp(float v) { return (int)(v * getResources().getDisplayMetrics().density + .5f); }
    private TextView text(String s, int size, int color, boolean bold) {
        TextView t = new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color);
        t.setGravity(Gravity.CENTER_VERTICAL);
        if (bold) t.setTypeface(Typeface.create("sans-serif", Typeface.BOLD));
        return t;
    }
    private LinearLayout column() {
        LinearLayout l = new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL); return l;
    }
    private LinearLayout.LayoutParams lp(int w, int h) { return new LinearLayout.LayoutParams(w < 0 ? w : dp(w), h < 0 ? h : dp(h)); }
    private void buildScreen() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        LinearLayout root = column();
        root.setPadding(dp(22), dp(22), dp(22), dp(20));
        root.setBackground(new GradientDrawable(GradientDrawable.Orientation.TL_BR,
                new int[]{Color.rgb(7,17,37), Color.rgb(4,10,23), Color.rgb(8,25,48)}));
        scroll.addView(root);
        setContentView(scroll);

        LinearLayout top = new LinearLayout(this);
        top.setGravity(Gravity.CENTER_VERTICAL);
        TextView mark = text("S", 20, Color.WHITE, true);
        mark.setGravity(Gravity.CENTER);
        mark.setBackground(shape(Color.rgb(21,90,137), CYAN, 15));
        top.addView(mark, lp(42,42));
        LinearLayout brand = column(); brand.setPadding(dp(11),0,0,0);
        brand.addView(text("SPTI  /  CONTROL", 13, Color.WHITE, true));
        brand.addView(text("SYSTEM INTERFACE  ·  VERSION 2.0", 9, MUTED, false));
        top.addView(brand, new LinearLayout.LayoutParams(0, -2, 1));
        TextView status = text("●  READY", 10, CYAN, true);
        status.setPadding(dp(12),dp(8),dp(12),dp(8));
        status.setBackground(shape(Color.rgb(12,49,68), Color.rgb(27,115,148), 30));
        top.addView(status);
        root.addView(top);

        Space sp = new Space(this); root.addView(sp, lp(1,48));
        TextView eyebrow = text("NEXT-GEN MOBILE CONTROL", 11, CYAN, true);
        root.addView(eyebrow);
        TextView title = text("掌控每一次\n交互体验", 34, Color.WHITE, true);
        title.setLineSpacing(dp(5),1f);
        root.addView(title, lp(-1,-2));
        TextView sub = text("SPTI 组合式独立控制面板", 14, MUTED, false);
        LinearLayout.LayoutParams sublp = lp(-1,30); sublp.topMargin=dp(10); root.addView(sub,sublp);

        LinearLayout hero = column();
        hero.setPadding(dp(18),dp(18),dp(18),dp(18));
        hero.setBackground(shape(Color.rgb(14,34,59), Color.rgb(39,100,139), 22));
        LinearLayout.LayoutParams hp = lp(-1,-2); hp.topMargin=dp(28); root.addView(hero,hp);
        LinearLayout row = new LinearLayout(this); row.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout heroTitle = column();
        heroTitle.addView(text("CONTROL CENTER", 11, CYAN, true));
        heroTitle.addView(text("系统运行状态", 18, Color.WHITE, true));
        row.addView(heroTitle,new LinearLayout.LayoutParams(0,-2,1));
        TextView live = text("LIVE",10,Color.rgb(109,240,194),true);
        live.setPadding(dp(11),dp(6),dp(11),dp(6)); live.setBackground(shape(Color.rgb(15,67,66),0,20));
        row.addView(live); hero.addView(row);
        TextView desc = text("界面已就绪。启动悬浮控制台后，可在屏幕任意位置展开模块面板。",12,MUTED,false);
        desc.setLineSpacing(dp(4),1f);
        LinearLayout.LayoutParams dp1=lp(-1,-2); dp1.topMargin=dp(14); hero.addView(desc,dp1);

        LinearLayout stats = new LinearLayout(this);
        String[][] values = {{"03","独立模块"},{"02","控制层级"},{"2.0","当前版本"}};
        for (String[] v: values) {
            LinearLayout c=column(); c.setPadding(dp(12),dp(12),dp(8),dp(12));
            c.setBackground(shape(Color.rgb(9,23,43),Color.rgb(28,62,91),15));
            TextView n=text(v[0],21,Color.WHITE,true); c.addView(n);
            c.addView(text(v[1],10,MUTED,false));
            LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(0,-2,1);
            cp.topMargin=dp(16); if (!v[0].equals("03")) cp.leftMargin=dp(8);
            stats.addView(c,cp);
        }
        hero.addView(stats);

        TextView section=text("快速启动",16,Color.WHITE,true);
        LinearLayout.LayoutParams secp=lp(-1,28); secp.topMargin=dp(26); root.addView(section,secp);
        TextView grant=button("01   授予屏幕悬浮权限",false);
        LinearLayout.LayoutParams bp=lp(-1,54); bp.topMargin=dp(12); root.addView(grant,bp);
        grant.setOnClickListener(v -> {
            if (Build.VERSION.SDK_INT >= 23 && !Settings.canDrawOverlays(this)) {
                Intent i=new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:"+getPackageName()));
                startActivity(i);
            } else Toast.makeText(this,"悬浮权限已授予",Toast.LENGTH_SHORT).show();
        });
        TextView access=button("02   启用音量键控制（无障碍权限）",false);
        LinearLayout.LayoutParams ap=lp(-1,54); ap.topMargin=dp(10); root.addView(access,ap);
        access.setOnClickListener(v -> startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));

        TextView start=button("启动 SPTI 悬浮控制台   →",true);
        LinearLayout.LayoutParams bp2=lp(-1,58); bp2.topMargin=dp(12); root.addView(start,bp2);
        start.setOnClickListener(v -> {
            if (Build.VERSION.SDK_INT >= 23 && !Settings.canDrawOverlays(this)) {
                Toast.makeText(this,"请先授予屏幕悬浮权限",Toast.LENGTH_LONG).show();
                startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,Uri.parse("package:"+getPackageName())));
                return;
            }
            if (!authorized) { Toast.makeText(this,"启动授权未通过",Toast.LENGTH_LONG).show(); finish(); return; }
            Intent overlayIntent = new Intent(this,OverlayService.class);
            overlayIntent.putExtra("launch_ticket", verifiedTicket);
            overlayIntent.putExtra("device_id", verifiedDeviceId);
            startService(overlayIntent);
            Toast.makeText(this,"SPTI 悬浮控制台已启动",Toast.LENGTH_SHORT).show();
        });

        Space bottom = new Space(this); root.addView(bottom,lp(1,30));
        View line=new View(this); line.setBackgroundColor(Color.rgb(31,57,83)); root.addView(line,lp(-1,1));
        LinearLayout foot=new LinearLayout(this); foot.setGravity(Gravity.CENTER_VERTICAL);
        TextView f1=text("SPTI  SYSTEMS",10,MUTED,true);
        foot.addView(f1,new LinearLayout.LayoutParams(0,dp(36),1));
        foot.addView(text("DESIGNED FOR MOBILE",9,Color.rgb(75,112,145),true));
        root.addView(foot);
        root.setAlpha(0f); root.setTranslationY(dp(18));
        root.animate().alpha(1f).translationY(0).setDuration(650).setInterpolator(new DecelerateInterpolator()).start();
        ValueAnimator pulse=ValueAnimator.ofFloat(.65f,1f); pulse.setDuration(1800); pulse.setRepeatCount(ValueAnimator.INFINITE); pulse.setRepeatMode(ValueAnimator.REVERSE);
        pulse.addUpdateListener(a -> status.setAlpha((Float)a.getAnimatedValue())); pulse.start();
    }
    @Override protected void onDestroy() {
        authExecutor.shutdownNow();
        super.onDestroy();
    }

    private TextView button(String label, boolean primary) {
        TextView b=text(label,14,primary?Color.rgb(3,20,34):Color.rgb(221,239,252),true);
        b.setGravity(Gravity.CENTER);
        b.setBackground(shape(primary?Color.rgb(57,192,235):Color.rgb(17,42,68),
                primary?Color.rgb(118,229,255):Color.rgb(44,91,128),16));
        b.setElevation(dp(primary?7:2));
        b.setOnTouchListener((v,e)->{
            if(e.getAction()==android.view.MotionEvent.ACTION_DOWN) v.animate().scaleX(.985f).scaleY(.985f).setDuration(90).start();
            if(e.getAction()==android.view.MotionEvent.ACTION_UP || e.getAction()==android.view.MotionEvent.ACTION_CANCEL) v.animate().scaleX(1f).scaleY(1f).setDuration(120).start();
            return false;
        });
        return b;
    }
}
