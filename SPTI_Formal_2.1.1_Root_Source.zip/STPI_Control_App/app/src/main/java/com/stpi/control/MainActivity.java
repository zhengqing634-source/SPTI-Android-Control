
package com.stpi.control;

import android.app.Activity;
import android.content.ComponentName;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.graphics.Color;
import android.view.Gravity;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Button;
import android.widget.Toast;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {

    private static final String VERIFY_URL =
        "https://moortluitlpcuhqzfqky.supabase.co/functions/v1/stpi-launch-ticket";

    private static final String API_KEY =
        "sb_publishable_DyV6nf8RVv-d-XllYdt0LQ_uJG87R_L";

    private static final String GAME_PACKAGE =
        "com.miniworldroyale.sparkgame.mi";

    private static final String GAME_ACTIVITY =
        "com.unity3d.player.base.StartUpActivity";

    private final ExecutorService executor =
        Executors.newSingleThreadExecutor();

    private final Handler handler =
        new Handler(Looper.getMainLooper());

    private String ticket;
    private String deviceId;

    private boolean verifying = false;
    private boolean finished = false;
    private boolean permissionRequested = false;

    @Override
    public void onCreate(Bundle state) {
        super.onCreate(state);

        getWindow().setStatusBarColor(Color.rgb(10, 16, 29));
        getWindow().setNavigationBarColor(Color.rgb(10, 16, 29));

        ticket = getIntent().getStringExtra("launch_ticket");
        deviceId = getIntent().getStringExtra("device_id");

        if (ticket == null || ticket.trim().isEmpty()
                || deviceId == null || deviceId.trim().isEmpty()) {
            reject("请通过授权脚本启动 SPTI");
            return;
        }

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(1);
        root.setGravity(Gravity.CENTER);
        root.setPadding(48, 48, 48, 48);
        root.setBackgroundColor(Color.rgb(10, 16, 29));

        TextView logo = new TextView(this);
        logo.setText("ＳＰＴＩ");
        logo.setTextSize(38);
        logo.setTextColor(Color.rgb(125, 190, 255));
        logo.setGravity(Gravity.CENTER);

        TextView sub = new TextView(this);
        sub.setText("SYSTEM CONTROL INTERFACE\n授权启动系统");
        sub.setTextColor(Color.WHITE);
        sub.setGravity(Gravity.CENTER);

        Button permissionButton = new Button(this);
        permissionButton.setText("检查悬浮窗权限");

        root.addView(logo);
        root.addView(sub);
        root.addView(permissionButton);

        setContentView(root);

        permissionButton.setOnClickListener(v -> checkPermission());
    }

    private void checkPermission() {
        if (finished || verifying) return;

        if (!Settings.canDrawOverlays(this)) {
            if (!permissionRequested) {
                permissionRequested = true;

                Intent intent = new Intent(
                    Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:" + getPackageName())
                );

                startActivityForResult(intent, 701);
            }
            return;
        }

        verifyTicket();
    }

    @Override
    protected void onActivityResult(
            int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == 701) {
            if (Settings.canDrawOverlays(this)) {
                verifyTicket();
            } else {
                reject("未授予悬浮窗权限，启动取消");
            }
        }
    }

    @Override
    protected void onResume() {
        super.onResume();

        if (!finished && !verifying && ticket != null
                && Settings.canDrawOverlays(this)) {
            verifyTicket();
        }
    }

    private void verifyTicket() {
        if (finished || verifying || ticket == null) return;

        verifying = true;

        final String currentTicket = ticket;
        final String currentDeviceId = deviceId;

        executor.execute(() -> {
            HttpURLConnection connection = null;
            boolean valid = false;
            String error = "服务器验证失败";

            try {
                URL url = new URL(VERIFY_URL);
                connection = (HttpURLConnection) url.openConnection();

                connection.setRequestMethod("POST");
                connection.setConnectTimeout(15000);
                connection.setReadTimeout(15000);
                connection.setDoOutput(true);

                connection.setRequestProperty(
                    "Content-Type",
                    "application/json; charset=utf-8"
                );

                connection.setRequestProperty("apikey", API_KEY);

                JSONObject request = new JSONObject();
                request.put("action", "verify");
                request.put("ticket", currentTicket);
                request.put("device_id", currentDeviceId);

                try (OutputStream output = connection.getOutputStream()) {
                    output.write(
                        request.toString().getBytes(StandardCharsets.UTF_8)
                    );
                }

                int status = connection.getResponseCode();

                InputStream stream;

                if (status >= 200 && status < 300) {
                    stream = connection.getInputStream();
                } else {
                    stream = connection.getErrorStream();
                }

                StringBuilder response = new StringBuilder();

                if (stream != null) {
                    try (BufferedReader reader = new BufferedReader(
                            new InputStreamReader(
                                stream, StandardCharsets.UTF_8))) {

                        String line;

                        while ((line = reader.readLine()) != null) {
                            response.append(line);
                        }
                    }
                }

                JSONObject result =
                    new JSONObject(response.toString());

                valid = status >= 200 && status < 300
                    && result.optBoolean("ok", false)
                    && result.optBoolean("valid", false);

                if (!valid) {
                    error = result.optString(
                        "code", "票据无效或已经过期"
                    );
                }

            } catch (Exception e) {
                error = "无法连接授权服务器，请检查网络";
            } finally {
                if (connection != null) {
                    connection.disconnect();
                }
            }

            final boolean verificationPassed = valid;
            final String errorMessage = error;

            handler.post(() -> {
                ticket = null;
                deviceId = null;

                if (finished || isFinishing()) return;

                if (verificationPassed) {
                    launchGameAndPanel();
                } else {
                    reject(errorMessage);
                }
            });
        });
    }

    private void launchGameAndPanel() {
        if (finished) return;

        try {
            // 启动 SPTI 悬浮控制服务
            Intent serviceIntent =
                new Intent(this, OverlayService.class);

            serviceIntent.putExtra("profile", "AxAeRifvX");

            startService(serviceIntent);

            // 使用已经确认的正式版游戏 Activity
            Intent gameIntent = new Intent();

            gameIntent.setComponent(new ComponentName(
                GAME_PACKAGE,
                GAME_ACTIVITY
            ));

            gameIntent.addFlags(
                Intent.FLAG_ACTIVITY_NEW_TASK
            );

            startActivity(gameIntent);

            finished = true;
            Toast.makeText(
                this,
                "授权成功，SPTI 与游戏启动请求已发送",
                Toast.LENGTH_LONG
            ).show();

            finish();

        } catch (Exception e) {
            stopService(
                new Intent(this, OverlayService.class)
            );

            reject("游戏启动失败，请确认正式版游戏已安装");
        }
    }

    private void reject(String message) {
        if (finished) return;

        finished = true;

        Toast.makeText(
            this,
            message,
            Toast.LENGTH_LONG
        ).show();

        finish();
    }

    @Override
    protected void onDestroy() {
        ticket = null;
        deviceId = null;

        executor.shutdownNow();

        super.onDestroy();
    }
}
