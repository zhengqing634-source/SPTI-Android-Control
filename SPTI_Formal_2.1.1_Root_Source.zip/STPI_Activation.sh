#!/system/bin/sh
# SPTI formal launcher: license status/activation -> short-lived server ticket -> APK
# No signing secret is stored in this script or in the APK.

APP_COMPONENT="com.stpi.control/.MainActivity"
BASE_URL="https://moortluitlpcuhqzfqky.supabase.co/functions/v1"
LICENSE_URL="$BASE_URL/stpi-license-activation"
TICKET_URL="$BASE_URL/stpi-launch-ticket"
PUBLIC_API_KEY="sb_publishable_DyV6nf8RVv-d-XllYdt0LQ_uJG87R_L"
ROOT="/sdcard/STPI"
CONFIG="$ROOT/config"
DEVICE_FILE="$CONFIG/device.id"

say() { printf '%s\n' "$*"; }
fail() { say "错误：$*"; exit 1; }

command -v su >/dev/null 2>&1 || fail "未检测到 su，设备未提供 Root 管理接口。"
ROOT_CHECK="$(su -c id 2>/dev/null)" || fail "未获得 Root 授权。请在 Root 管理器中允许本脚本，然后重新运行。"
case "$ROOT_CHECK" in
    *"uid=0"*) ;;
    *) fail "Root 授权未通过（未检测到 uid=0）。" ;;
esac

command -v curl >/dev/null 2>&1 || fail "当前环境没有 curl，无法连接授权服务器。请在支持 curl 的终端中运行此脚本。"
command -v am >/dev/null 2>&1 || fail "未检测到 Android am 命令。"
mkdir -p "$CONFIG" || fail "无法创建配置目录。"

if [ ! -s "$DEVICE_FILE" ]; then
    DEVICE_ID="$(cat /proc/sys/kernel/random/uuid 2>/dev/null | tr -d '-')"
    [ ${#DEVICE_ID} -ge 16 ] || fail "无法生成设备标识。"
    umask 077
    printf '%s' "$DEVICE_ID" > "$DEVICE_FILE" || fail "无法保存设备标识。"
else
    DEVICE_ID="$(cat "$DEVICE_FILE" 2>/dev/null | tr -d '\r\n')"
fi
[ ${#DEVICE_ID} -ge 16 ] && [ ${#DEVICE_ID} -le 128 ] || fail "设备标识文件无效，请保留原文件并联系管理员。"

post_json() {
    URL="$1"
    BODY="$2"
    curl -sS --connect-timeout 10 --max-time 20 \
        -X POST "$URL" \
        -H "Content-Type: application/json" \
        -H "apikey: $PUBLIC_API_KEY" \
        --data "$BODY"
}

is_ok() { printf '%s' "$1" | grep -q '"ok"[[:space:]]*:[[:space:]]*true'; }

say "SPTI 正在检查设备授权…"
STATUS_BODY="$(printf '{"action":"status","device_id":"%s"}' "$DEVICE_ID")"
STATUS_RESPONSE="$(post_json "$LICENSE_URL" "$STATUS_BODY")" || fail "授权服务器连接失败。"

if ! is_ok "$STATUS_RESPONSE"; then
    say "当前设备尚未验证通过，请输入授权卡密。"
    printf '授权卡密：'
    if [ -t 0 ]; then
        stty -echo 2>/dev/null
        IFS= read -r LICENSE_KEY
        stty echo 2>/dev/null
        printf '\n'
    else
        IFS= read -r LICENSE_KEY
    fi
    [ -n "$LICENSE_KEY" ] || fail "未输入授权卡密。"
    ACTIVATE_BODY="$(printf '{"action":"activate","key":"%s","device_id":"%s"}' "$LICENSE_KEY" "$DEVICE_ID")"
    ACTIVATE_RESPONSE="$(post_json "$LICENSE_URL" "$ACTIVATE_BODY")" || fail "激活请求失败。"
    LICENSE_KEY=""
    ACTIVATE_BODY=""
    if ! is_ok "$ACTIVATE_RESPONSE"; then
        ACTIVATE_RESPONSE=""
        fail "卡密验证未通过，请检查卡密状态或联系管理员。"
    fi
    ACTIVATE_RESPONSE=""
fi
STATUS_RESPONSE=""

say "设备授权有效，正在申请短时启动票据…"
ISSUE_BODY="$(printf '{"action":"issue","device_id":"%s"}' "$DEVICE_ID")"
ISSUE_RESPONSE="$(post_json "$TICKET_URL" "$ISSUE_BODY")" || fail "启动票据申请失败。"
if ! is_ok "$ISSUE_RESPONSE"; then
    ISSUE_RESPONSE=""
    fail "服务器未签发启动票据，请检查网络或授权状态。"
fi
TICKET="$(printf '%s' "$ISSUE_RESPONSE" | sed -n 's/.*"ticket"[[:space:]]*:[[:space:]]*"\([^"\\]*\)".*/\1/p')"
ISSUE_RESPONSE=""
[ -n "$TICKET" ] || fail "服务器响应中没有有效票据。"

say "验证通过，正在启动 SPTI…"
am start -n "$APP_COMPONENT" --es launch_ticket "$TICKET" --es device_id "$DEVICE_ID" >/dev/null 2>&1
RESULT=$?
TICKET=""
[ "$RESULT" -eq 0 ] || fail "无法启动 SPTI 应用，请确认 APK 已安装。"
say "SPTI 已启动。"
